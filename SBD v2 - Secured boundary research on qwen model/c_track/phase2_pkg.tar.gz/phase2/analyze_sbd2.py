#!/usr/bin/env python3
"""Summarize SBD trajectories. Usage: analyze_sbd2.py results_dir"""
import json, math, sys
from pathlib import Path


def wilson(k, n, z=1.96):
    if n == 0:
        return 0.0, 1.0
    p = k / n; d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return max(0.0, c - h), min(1.0, c + h)


rd = Path(sys.argv[1])
runs = [json.loads(p.read_text()) for p in sorted(rd.glob("seed_*.json"))]
N = len(runs)
if not N:
    sys.exit("no results found")
K = max(r["n_edits"] for r in runs)
model = runs[0]["model"]
cross = [r for r in runs if r["sbd"] is not None]
print(f"=== SBD pilot: {model} ===")
print(f"trajectories: {N}   edit budget K = {K}   crossings: {len(cross)}\n")

print("Cumulative crossing rate by edit depth (SBD <= k), with 95% Wilson CI:")
for k in range(K):
    c = sum(1 for r in runs if r["sbd"] is not None and r["sbd"] <= k)
    lo, hi = wilson(c, N)
    print(f"  within {k+1:2d} edits: {c:3d}/{N}  {100*c/N:5.1f}%  [{100*lo:.1f}-{100*hi:.1f}]")
if not cross:
    ub = 1 - 0.05 ** (1 / N)
    print(f"\nNo crossings: with 0/{N}, the exact 95% upper bound on the crossing rate within K={K} edits is {100*ub:.1f}%.")
    print(f"=> SBD > {K} edits for this model on this testbed (right-censored).")
else:
    sbds = sorted(r["sbd"] + 1 for r in cross)
    print(f"\nSBD among crossing trajectories (edits until first crossing): {sbds}")
    print(f"median over crossing runs: {sbds[len(sbds)//2]}   (censored runs: {N-len(cross)} had SBD > {K})")

print("\nPer-edit outcomes (over trajectories that reached the edit):")
print(f"{'edit':>4} {'reached':>7} {'rejected':>8} {'compile':>7} {'func':>5} {'trunc':>5} {'cross':>5}  prompt")
for i in range(K):
    recs = [x for r in runs for x in r["records"] if x["edit_index"] == i]
    if not recs:
        continue
    rej = sum(x["rejected"] for x in recs)
    cf = sum(not x["compile_ok"] for x in recs)
    ff = sum(x["compile_ok"] and not x["functional_pass"] for x in recs)
    tr = sum(x["truncated"] for x in recs)
    cr = sum(x["crossing"] for x in recs)
    print(f"{i+1:4d} {len(recs):7d} {rej:8d} {cf:7d} {ff:5d} {tr:5d} {cr:5d}  {recs[0]['prompt'][:58]}")

oe = sum(1 for r in runs for x in r["records"] if not x["rejected"] and x["security_pass"] is None)
je = sum(1 for r in runs for x in r["records"] if x["judge_ok"] is False)
print(f"\noracle errors (old test could not compile): {oe};  strict-judge compile errors: {je}")

if cross:
    print("\nCrossings (verify each by hand):")
    for r in cross:
        x = r["records"][r["sbd"]]
        print(f"- seed {r['seed']} edit {r['sbd']+1}: {x['prompt'][:70]}")
        print(f"    vectors: {x['finding_vectors'][:5]}")
        print(f"    evidence: {x['security_output'][-300:].strip()[:300]!r}")
